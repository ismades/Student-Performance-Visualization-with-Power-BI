# -*- coding: utf-8 -*-
"""
Created on Fri Feb  7 20:44:41 2025

@author: user
"""
import pandas as pd 

data = "C:/Users/user/Documents/tugas bootcamp/Final Project 2/StudentsPerformance unclear.csv"
df = pd.read_csv(data)


    
df.rename(columns = {"gender":"Gender", 
                     "race/ethnicity": "Race/Ethnicity",
                     "parental level of education":"Parental Level of Education",
                     "lunch":"Lunch",
                     "test preparation course":"Test Preparation Course",
                     "math score":"Math Score",
                     "reading score":"Reading Score",
                     "writing score":"Writing Score"}, inplace=True)


kapital = "Gender","Race/Ethnicity", "Parental Level of Education","Lunch","Test Preparation Course"
for kolom in kapital:
    df[kolom] = df[kolom].astype(str).str.lower().str.title().str.replace("'S", "'s")

    
score = ["Math Score","Reading Score","Writing Score"]
for kolom in score:
    df[kolom] = df[kolom].astype(str).str[:2].astype(int) 

print(df.head())

df.to_excel("penilaian murid 2.xlsx",index = False, engine = "openpyxl")
print("data tersimpan")





